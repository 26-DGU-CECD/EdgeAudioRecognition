from __future__ import annotations
import csv, hashlib, json
from pathlib import Path
import numpy as np
from policy_core import MODEL_NAMES, fuse_logits


class ProjectFiles:
    def __init__(self, project_root, extra_roots=()):
        self.root = Path(project_root).expanduser().resolve()
        self.roots = [self.root] + [Path(p).expanduser().resolve() for p in extra_roots]
        if not self.root.is_dir():
            raise FileNotFoundError(self.root)

    def locate(self, relative):
        candidates = [root / relative for root in self.roots if (root / relative).is_file()]
        if not candidates:
            raise FileNotFoundError(f"{relative}: not found under {self.roots}")
        if len(candidates) > 1:
            hashes = {hashlib.sha256(p.read_bytes()).hexdigest() for p in candidates}
            if len(hashes) != 1:
                raise ValueError(f"Conflicting source copies: {relative}")
        return candidates[0]

    @property
    def class_names(self):
        return [s.strip() for s in self.locate("class_names.txt").read_text(
            encoding="utf-8-sig").splitlines() if s.strip()]


def experiment_paths(assignment="predefined", ratio=0.70):
    if not 0 < ratio <= 1:
        raise ValueError("ratio must be in (0,1]")
    tag = f"nonexpert_{int(round(ratio * 100)):03d}"
    if assignment == "predefined":
        return f"runs/E_predefined_specialists/{tag}", f"runs/F_predefined_weighted_ensemble/{tag}"
    if assignment == "automatic":
        return f"runs/G_auto_specialists/{tag}", f"runs/G_auto_weighted_ensemble/{tag}"
    raise ValueError(assignment)


def read_weights(files, ensemble_dir, class_names):
    rows = list(csv.DictReader(files.locate(
        f"{ensemble_dir}/classwise_model_weights.csv").open(
            encoding="utf-8-sig", newline="")))
    if [row[next(iter(row))] for row in rows] != class_names:
        raise ValueError("Weight class order does not match class_names.txt")
    return np.array([[float(row[m]) for row in rows] for m in MODEL_NAMES])


def load_aligned_predictions(files, specialist_dir, split="val"):
    canonical, truth, logits = None, None, []
    for model in MODEL_NAMES:
        with np.load(files.locate(f"{specialist_dir}/{model}/{split}_predictions.npz"),
                     allow_pickle=False) as data:
            paths = data["paths"].astype(str)
            y = data["y_true"].astype(np.int64)
            z = data["logits"].astype(np.float64)
        if len(set(paths.tolist())) != len(paths):
            raise ValueError("Duplicate prediction paths")
        if canonical is None:
            canonical, truth = paths, y
        else:
            index = {p: i for i, p in enumerate(paths)}
            if set(index) != set(canonical.tolist()):
                raise ValueError("Prediction path mismatch")
            order = np.array([index[p] for p in canonical])
            y, z = y[order], z[order]
            if not np.array_equal(y, truth):
                raise ValueError("Targets do not align")
        logits.append(z)
    return canonical, truth, np.stack(logits)


def write_json(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False),
                          encoding="utf-8")


def write_csv(path, rows):
    if not rows:
        return
    with Path(path).open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def common_args(parser):
    parser.add_argument("--project-root", required=True)
    parser.add_argument("--extra-root", action="append", default=[])
    parser.add_argument("--assignment", choices=["predefined", "automatic"], default="predefined")
    parser.add_argument("--ratio", type=float, default=0.70)
    parser.add_argument("--out", default="pilot_results")

